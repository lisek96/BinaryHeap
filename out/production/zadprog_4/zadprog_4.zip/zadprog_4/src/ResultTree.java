import com.sun.source.tree.Tree;
import org.w3c.dom.Node;

import java.util.Arrays;

public class ResultTree {
    TreeNode root;
    String[] resultSource;

    ResultTree(prefixCodesCreator pcc) {
        resultSource = pcc.mergingHistory;
        root = new TreeNode(resultSource[pcc.index]);
    }
    //resultSource.length-1)
    void divide(int index, TreeNode parentNode){
        //usuwac wykorzystany lable i sprawdzac po prostu znullem, wtedy nie bd trzeba uzywac metody startswith

        if(resultSource[index] != null) {
            String[] split = resultSource[index].split("\\+");
            if (parentNode.label.startsWith(split[0])) {
                resultSource[index] = null;
                TreeNode right = new TreeNode(split[1], parentNode.code + "1");
                TreeNode left = new TreeNode(split[0], parentNode.code + "0");
                parentNode.rightChild = right;
                parentNode.leftChild = left;
                right.parent = parentNode;
                left.parent = parentNode;
                boolean divideLeft=true;
                boolean divideRight=true;
                if (left.label.length() == 1)  {
                    System.out.println(left.label + " " + left.code);
                    divideLeft=false;
                }
                if (right.label.length() == 1) {
                    System.out.println(right.label + " " + right.code);
                    divideRight=false;
                }

                if(divideRight) divide(index - 1, right);
                if(divideLeft) divide(index - 1, left);
            }
            else divide(index-1, parentNode);
        }
        else divide(index-1, parentNode);
    }


}
