public class TreeNode {
    String label;
    TreeNode rightChild;
    TreeNode leftChild;
    TreeNode parent;
    String code = "";

    TreeNode(String label){
        this.label=label;
        code = "";
    }

    TreeNode(String label, String code){
        this.label=label;
        this.code=code;
    }

    public String toString(){
        return label;
    }


}
